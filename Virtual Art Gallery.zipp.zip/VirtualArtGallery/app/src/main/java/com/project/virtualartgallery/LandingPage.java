package com.project.virtualartgallery;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class LandingPage extends AppCompatActivity {
    private static final long SPLASH_DURATION = 5000; // 5 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               checkUserAuthentication();
            }
        }, SPLASH_DURATION);
    }
    private void checkUserAuthentication() {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            Intent homeIntent = new Intent(LandingPage.this, HomeScreen.class);
            startActivity(homeIntent);
        } else {
            Intent loginIntent = new Intent(LandingPage.this, HomeScreen.class);
            startActivity(loginIntent);
        }
        finish();
    }
}
