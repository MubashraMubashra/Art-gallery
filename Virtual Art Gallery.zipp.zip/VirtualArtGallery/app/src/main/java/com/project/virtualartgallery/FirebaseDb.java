package com.project.virtualartgallery;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public  class FirebaseDb {
    private DatabaseReference databaseReference;
    private Context context;

    public FirebaseDb(Context context) {
        this.context=context;
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference();
    }
    public void createData(String path,String key, Object data,Class<?> targetActivityClass,String notification) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            if(notification.isEmpty()){
                notification ="Information Saved successfully";
            }
        }


        String finalNotification = notification;
        assert key != null;
        databaseReference.child(path).child(key).setValue(data).addOnSuccessListener(aVoid -> {
                    Toast.makeText(context, ""+finalNotification, Toast.LENGTH_SHORT).show();
                    context.startActivity(new Intent(context,targetActivityClass));
                    ((Activity) context).finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Failed to save information"+e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    public void readSingleData(String path,String key, ValueEventListener valueEventListener) {
        databaseReference.child(path).child(key).addListenerForSingleValueEvent(valueEventListener);
    }

}

