package com.project.virtualartgallery;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    EditText name,email,phone,password;
    Button btnadd,btnlogin;
    FirebaseAuth auth;
    FirebaseDb firebaseDb;
    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        FirebaseApp.initializeApp(this);
        name= findViewById(R.id.inputName_v);
        email= findViewById(R.id.inputEmail);
        phone= findViewById(R.id.inputPhone);
        password= findViewById(R.id.inputPassword);
        btnadd= findViewById(R.id.btnRegisterVote_v);
        btnlogin= findViewById(R.id.btnsign);
        auth = FirebaseAuth.getInstance();
        firebaseDb = new FirebaseDb(this);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Register.this,Login.class));

            }
        });
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name = name.getText().toString().trim();
                String Email = email.getText().toString().trim().toLowerCase();
                String Phone = phone.getText().toString().trim();
                String Password = password.getText().toString().trim().toLowerCase();
                if (TextUtils.isEmpty(Name)) {
                    name.setError("Required");
                } else if (TextUtils.isEmpty(Email)) {
                    email.setError("Required");
                } else if (TextUtils.isEmpty(Phone)) {
                    phone.setError("Required");
                } else if (TextUtils.isEmpty(Password)) {
                    password.setError("Required");
                }
                else {
                    auth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if(task.isSuccessful()){
                                        String UID= auth.getUid();
                                        assert UID != null;
                                        Toast.makeText(Register.this, "success auth", Toast.LENGTH_SHORT).show();
                                        User user= new User(UID,Name,Email,Phone,Password);
                                        firebaseDb.createData("user",UID,user, Login.class,"Successfully user registered");
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                    Toast.makeText(Register.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });
    }
}