package com.project.virtualartgallery.Comment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;


import com.project.virtualartgallery.R;

import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentsViewHolder> {
    private final List<Comment> commentsList;

    public CommentAdapter(List<Comment> commentsList) {
        this.commentsList = commentsList;
    }

    public static class CommentsViewHolder extends RecyclerView.ViewHolder {
        TextView textViewComment;
        TextView textViewUser;

        public CommentsViewHolder(View itemView) {
            super(itemView);
            textViewComment = itemView.findViewById(R.id.textViewComment);
            textViewUser = itemView.findViewById(R.id.textViewUser);
        }
    }

    @Override
    public CommentsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
        return new CommentsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CommentsViewHolder holder, int position) {
        Comment comment = commentsList.get(position);
        holder.textViewComment.setText(comment.getCommentText());
        holder.textViewUser.setText(String.valueOf(comment.getCommentor()));
    }

    @Override
    public int getItemCount() {
        return commentsList.size();
    }
}
