package com.project.virtualartgallery;

public class Artwork {
    private String id;
    private String title;
    private String category;

    private String price;

    private String imagePath;

    public Artwork() {}

    public Artwork(String id, String title, String category, String price, String imagePath) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.price = price;
        this.imagePath = imagePath;
    }

    public String getPrice() {
        return price;
    }

    public Artwork(String id, String title, String category, String imagePath) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.imagePath = imagePath;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getImagePath() {
        return imagePath;
    }
}
