package com.project.virtualartgallery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.project.virtualartgallery.Comment.Comment;
import com.project.virtualartgallery.Comment.CommentDbHelper;
import com.project.virtualartgallery.Comment.CommentAdapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Environment;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class ArtworkDetails extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1;


    private ImageView imageViewArtwork;

    private TextView textViewArtworkTitle;
    private TextView textViewArtworkDescription;
    private RecyclerView recyclerViewComments;
    private CommentAdapter commentAdapter;
    private List<Comment> commentList;
    private long artist_id = 0;

    private String art_title = "";
    private String art_des = "";

    private String art_img = "";




    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_artwork);

        Button buttonSaveArtwork = findViewById(R.id.buttonSaveArtwork);

        imageViewArtwork = findViewById(R.id.imageViewArtwork);
        textViewArtworkTitle = findViewById(R.id.textViewArtworkTitle);
        textViewArtworkDescription = findViewById(R.id.textViewArtworkDescription);
        recyclerViewComments = findViewById(R.id.recyclerViewComments);
        Bundle intent = getIntent().getExtras();
        artist_id = intent.getLong("id", 1);
        art_title = intent.getString("ProductName");
        art_des = intent.getString("ProductCategory");
        art_img = intent.getString("ProductImage");

        buttonSaveArtwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissions();
            }
        });



        Glide.with(this).load(art_img).into(imageViewArtwork);


        EditText editTextComment = findViewById(R.id.editTextComment);
        Button buttonPostComment = findViewById(R.id.buttonPostComment);

        buttonPostComment.setOnClickListener(v -> {
            String commentText = editTextComment.getText().toString().trim();
            if (!commentText.isEmpty()) {
                postComment(commentText); // Call method to post comment
                editTextComment.setText(""); // Clear the EditText after posting
            } else {
                Toast.makeText(this, "Please enter a comment", Toast.LENGTH_SHORT).show();
            }
        });


        textViewArtworkTitle.setText(art_title);
        textViewArtworkDescription.setText(art_des);

        commentList = new ArrayList<>();
        commentAdapter = new CommentAdapter(commentList);
        recyclerViewComments.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewComments.setAdapter(commentAdapter);
        loadCommentsForArtwork(artist_id);
    }
    private void saveArtwork() {
        BitmapDrawable drawable = (BitmapDrawable) imageViewArtwork.getDrawable();
        Bitmap bitmap = drawable.getBitmap();

        File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Artworks");
        if (!storageDir.exists()) {
            storageDir.mkdirs();
        }

        String fileName = "artwork_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(storageDir, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            Toast.makeText(this, "Artwork saved to: " + imageFile.getAbsolutePath(), Toast.LENGTH_LONG).show();

            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(imageFile)));
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save artwork", Toast.LENGTH_SHORT).show();
        }
    }


    private void postComment(String commentText) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        CommentDbHelper dbHelper = new CommentDbHelper(this);
        String commentor = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        Comment comment = new Comment(artist_id, commentor, commentText, timestamp);
        long commentId = dbHelper.insertComment(comment);
        if (commentId != -1L) {
            Comment newComment = new Comment(commentId, commentor, commentText, timestamp);
            commentList.add(newComment);
            commentAdapter.notifyDataSetChanged();
            Toast.makeText(this, "Comment posted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to post comment", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadCommentsForArtwork(long artworkId) {
        CommentDbHelper dbHelper = new CommentDbHelper(this);
        commentList.clear();
        commentList.addAll(dbHelper.getAllCommentsForArtwork(artworkId));
        commentAdapter.notifyDataSetChanged();
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        } else {
            saveArtwork();
        }
    }

    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveArtwork();
            } else {
                Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }


}


