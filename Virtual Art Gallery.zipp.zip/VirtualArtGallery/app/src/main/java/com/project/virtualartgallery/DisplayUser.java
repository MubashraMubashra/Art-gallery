package com.project.virtualartgallery;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DisplayUser extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<User> userDetails;
    private UserAdapter userAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_users);

        recyclerView = findViewById(R.id.recyclerView);
        userDetails = new ArrayList<>();
        userAdapter = new UserAdapter((ArrayList<User>) userDetails);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(userAdapter);

        FirebaseDatabase databaseRef = FirebaseDatabase.getInstance();
        databaseRef.getReference().child("user").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                userDetails.clear();
                Log.e("12345", userDetails.toString());
                for (DataSnapshot itemSnapshot : dataSnapshot.getChildren()) {
                    User menuItem = itemSnapshot.getValue(User.class);
                    userDetails.add(menuItem);
                }
                userAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("fetchDataFromDatabase", "Error fetching data: " + databaseError.getMessage());
            }
        });
    }
}
