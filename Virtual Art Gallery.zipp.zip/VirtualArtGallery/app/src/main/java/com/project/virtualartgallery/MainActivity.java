package com.project.virtualartgallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    FirebaseDb firebaseDb;
    TextView name,email,phone;
    Button logout;
    FirebaseAuth auth;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.userName);
        email=findViewById(R.id.userEmail);
        phone=findViewById(R.id.userPhone);
        logout=findViewById(R.id.logout);
        firebaseDb=new FirebaseDb(this);
         auth=FirebaseAuth.getInstance();
        String uid=auth.getUid();
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Log Out")
                        .setMessage("Are you sure you want to log out?")
                        .setPositiveButton("LogOut", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                signOutUser();
                            }

                            private void signOutUser() {
                                auth.signOut();
                                Toast.makeText(MainActivity.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(MainActivity.this, Register.class));
                            }
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
        firebaseDb.readSingleData("user", uid, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               if (snapshot.exists()){
                   String nameTxt=snapshot.child("name").getValue().toString();
                   String emailTxt=snapshot.child("email").getValue().toString();
                   String phoneTxt=snapshot.child("phone").getValue().toString();
                   name.setText(nameTxt);
                   email.setText(emailTxt);
                   phone.setText(phoneTxt);


               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
}