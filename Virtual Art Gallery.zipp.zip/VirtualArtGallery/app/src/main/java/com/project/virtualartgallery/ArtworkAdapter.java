package com.project.virtualartgallery;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class ArtworkAdapter extends RecyclerView.Adapter<ArtworkAdapter.ArtworkViewHolder> {
    private List<Artwork> artworkList;
    private List<Artwork> artworkListFull;
    Context context;

    public ArtworkAdapter(List<Artwork> artworkList, Context context) {
        this.artworkList = artworkList;
        this.context = context;
        artworkListFull = new ArrayList<>(artworkList);
    }

    @NonNull
    @Override
    public ArtworkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_artwork, parent, false);
        return new ArtworkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArtworkViewHolder holder, int position) {
        Artwork artwork = artworkList.get(position);

        holder.artworkTitle.setText(artwork.getTitle());
        holder.artworkCategory.setText(artwork.getPrice()+"Rs");
        Glide.with(context).load(artwork.getImagePath()).into(holder.artworkImage);


        holder.itemView.setOnClickListener(view -> {
            Intent intent=new Intent(context, ArtworkDetails.class);
            intent.putExtra("ProductName",artwork.getTitle());
            intent.putExtra("ProductPrice",artwork.getPrice());
            intent.putExtra("ProductCategory",artwork.getCategory());
            intent.putExtra("ProductImage",artwork.getImagePath());
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

        });
    }

    @Override
    public int getItemCount() {
        Log.e("list", String.valueOf(artworkList.size()));
        return artworkList.size();
    }


    public void filter(String text) {
        Log.d("ArtworkAdapter", "Filter called with text: " + text);
        artworkList.clear();
        if (text.isEmpty()) {
            artworkList.addAll(artworkListFull);
        } else {
            text = text.toLowerCase();
            for (Artwork item : artworkListFull) {
                if (item.getTitle().toLowerCase().contains(text) ||
                        item.getCategory().toLowerCase().contains(text)) {
                    artworkList.add(item);
                }
            }
        }
        Log.d("ArtworkAdapter", "Filtered list size: " + artworkList.size());

        notifyDataSetChanged();
    }
    static class ArtworkViewHolder extends RecyclerView.ViewHolder {
        TextView artworkTitle,artworkCategory;
        ImageView artworkImage;

        ArtworkViewHolder(@NonNull View itemView) {
            super(itemView);
            artworkTitle = itemView.findViewById(R.id.artworkTitle);
            artworkCategory = itemView.findViewById(R.id.artworkCategory);
            artworkImage = itemView.findViewById(R.id.artworkImage);
        }
    }
}

