package com.project.virtualartgallery.Comment;

public class Comment {
    private long artworkid;
    private String commentor;
    private String commentText;
    private String timestamp;

    public Comment(long artworkid, String commentor, String commentText, String timestamp) {
        this.artworkid = artworkid;
        this.commentor = commentor;
        this.commentText = commentText;
        this.timestamp = timestamp;
    }

    public long getArtworkid() {
        return artworkid;
    }

    public void setArtworkid(long artworkid) {
        this.artworkid = artworkid;
    }

    public String getCommentor() {
        return commentor;
    }

    public void setCommentor(String commentor) {
        this.commentor = commentor;
    }

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
