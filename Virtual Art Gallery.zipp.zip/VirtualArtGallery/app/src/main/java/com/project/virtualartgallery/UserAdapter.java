package com.project.virtualartgallery;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private ArrayList<User> userManagements;

    public UserAdapter(ArrayList<User> menuManagements) {
        this.userManagements = menuManagements;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        User userDetails = userManagements.get(position);
        holder.nameTextView.setText(userDetails.getName());
        holder.emailTextView.setText(userDetails.getEmail());
        holder.roleTextView.setText("User");
        holder.statusTextView.setText("Status: " + "Approved Account");
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "Do You want to select: " + userDetails.getEmail(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public int getItemCount() {
        Log.e("1234", String.valueOf(userManagements.size()));
        return userManagements.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView nameTextView;
        TextView emailTextView;
        TextView roleTextView;
        TextView statusTextView;

        public UserViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.name_text_view);
            emailTextView = itemView.findViewById(R.id.email_text_view);
            roleTextView = itemView.findViewById(R.id.role_text_view);
            statusTextView = itemView.findViewById(R.id.status_text_view);
        }
    }
}
