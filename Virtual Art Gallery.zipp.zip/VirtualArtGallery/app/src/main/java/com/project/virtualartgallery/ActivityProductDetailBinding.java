package com.project.virtualartgallery;

import android.view.LayoutInflater;
import android.widget.ImageView;

public class ActivityProductDetailBinding {
    public ImageView productimage;

    public static ActivityProductDetailBinding inflate(LayoutInflater layoutInflater) {
    }

    public int getRoot() {
    }
}
