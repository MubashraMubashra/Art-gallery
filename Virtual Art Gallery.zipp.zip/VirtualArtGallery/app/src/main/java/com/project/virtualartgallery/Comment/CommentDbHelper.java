package com.project.virtualartgallery.Comment;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class CommentDbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "ArtworkCommentsDB";
    private static final String TABLE_COMMENTS = "comments";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ARTWORK_ID = "artwork_id";
    private static final String COLUMN_COMMENTER_NAME = "commenter_name";
    private static final String COLUMN_COMMENT_TEXT = "comment_text";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    public CommentDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableSQL = "CREATE TABLE " + TABLE_COMMENTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_ARTWORK_ID + " INTEGER," +
                COLUMN_COMMENTER_NAME + " TEXT," +
                COLUMN_COMMENT_TEXT + " TEXT," +
                COLUMN_TIMESTAMP + " TEXT" +
                ")";
        db.execSQL(createTableSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
        onCreate(db);
    }

    public long insertComment(Comment comment) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_ARTWORK_ID, comment.getArtworkid());
        contentValues.put(COLUMN_COMMENTER_NAME, comment.getCommentor());
        contentValues.put(COLUMN_COMMENT_TEXT, comment.getCommentText());
        contentValues.put(COLUMN_TIMESTAMP, comment.getTimestamp());
        long id = db.insert(TABLE_COMMENTS, null, contentValues);
        db.close();
        return id;
    }

    @SuppressLint("Range")
    public ArrayList<Comment> getAllCommentsForArtwork(long artworkId) {
        ArrayList<Comment> commentsList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_COMMENTS + " WHERE " + COLUMN_ARTWORK_ID + " = " + artworkId + " ORDER BY " + COLUMN_TIMESTAMP + " DESC";
        android.database.Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(COLUMN_ID));
                String commenterName = cursor.getString(cursor.getColumnIndex(COLUMN_COMMENTER_NAME));
                String commentText = cursor.getString(cursor.getColumnIndex(COLUMN_COMMENT_TEXT));
                String timestamp = cursor.getString(cursor.getColumnIndex(COLUMN_TIMESTAMP));
                Comment comment = new Comment(id, commenterName, commentText, timestamp);
                commentsList.add(comment);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return commentsList;
    }
}

