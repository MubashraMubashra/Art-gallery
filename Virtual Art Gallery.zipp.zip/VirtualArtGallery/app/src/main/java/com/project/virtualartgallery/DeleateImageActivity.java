package com.project.virtualartgallery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;


import java.io.IOException;
import java.io.InputStream;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

public class DeleateImageActivity extends AppCompatActivity {

    private ImageView imageView;
    private Uri imageUri;
    private EditText titleEditText;
    private EditText priceEditText;
    private Spinner categorySpinner;
    private final ActivityResultLauncher<Uri> cameraResultLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), result -> {
                if (result) {
                    imageView.setImageURI(imageUri);
                } else {
                    Toast.makeText(this, "Camera deleate failed", Toast.LENGTH_SHORT).show();
                }
            });

    private final ActivityResultLauncher<String> galleryResultLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), result -> {
                if (result != null) {
                    imageUri = result;
                    imageView.setImageURI(imageUri);
                } else {
                    Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
                }
            });

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture_image);

        imageView = findViewById(R.id.imageView);
        titleEditText = findViewById(R.id.titleEditText);
        priceEditText = findViewById(R.id.priceEditText);
        categorySpinner = findViewById(R.id.categorySpinner);
        Button deleateButton = findViewById(R.id.deleateart);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.categories_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);
        deleateButton.setOnClickListener(v -> deleateImageToFirebase());
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            cameraResultLauncher.launch(imageUri);
        }
    }

    private void openGallery() {
        galleryResultLauncher.launch("image/*");
    }

    private void deleateImageToFirebase() {
        String title = titleEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();

        String category = categorySpinner.getSelectedItem().toString();

        if (imageUri != null && !title.isEmpty() && !category.isEmpty() && !price.isEmpty()) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReference("images/" + System.currentTimeMillis() + ".jpg");
            storageReference.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl()
                            .addOnSuccessListener(uri -> {
                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("deleateArts");
                                String deleateartworkId = databaseReference.push().getKey();
                                Map<String, String> artworkMap = new HashMap<>();
                                artworkMap.put("title", title);
                                artworkMap.put("category", category);
                                artworkMap.put("price", price);
                                artworkMap.put("imagePath", uri.toString());
                                databaseReference.child(deleateartworkId).setValue(artworkMap)
                                        .addOnSuccessListener(aVoid -> Toast.makeText(DeleateImageActivity.this, "Image deleate to database", Toast.LENGTH_SHORT).show())
                                        .addOnFailureListener(e -> Toast.makeText(DeleateImageActivity.this, "Failed to deleate image", Toast.LENGTH_SHORT).show());
                            }))
                    .addOnFailureListener(e -> Toast.makeText(DeleateImageActivity.this, "Failed to upload image", Toast.LENGTH_SHORT).show());
        } else {
            Toast.makeText(this, "Please fill all fields and select an image to deleate", Toast.LENGTH_SHORT).show();
        }
    }

}
