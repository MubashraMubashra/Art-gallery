package com.project.virtualartgallery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShowArts extends AppCompatActivity {

    private RecyclerView imageSlider, artworkRecyclerView, product_category_recycler_view;
    private ArtworkAdapter artworkAdapter;
    private ProductCategoryAdapter productCategoryAdapter;

    private ArrayList<Artwork> sketches = new ArrayList<>();
    private ArrayList<ProductCategory> productCategoryArrayList = new ArrayList<>();


    private Handler handler;
    private Runnable autoScrollRunnable;
    private int currentPosition = 0;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_sketches);


        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        setSupportActionBar(toolbar);

        imageSlider = findViewById(R.id.image_slider);


        List<Integer> images = Arrays.asList(
                R.drawable.art_slider1,
                R.drawable.art_slider2,
                R.drawable.art_slider3,
                R.drawable.art_slider4
        );

        SliderAdapter sliderAdapter = new SliderAdapter(this, images);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        imageSlider.setLayoutManager(layoutManager);
        imageSlider.setAdapter(sliderAdapter);

        SnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(imageSlider);

        handler = new Handler(Looper.getMainLooper());
        autoScrollRunnable = new Runnable() {
            @Override
            public void run() {
                currentPosition++;
                if (currentPosition >= sliderAdapter.getItemCount()) {
                    currentPosition = 0;
                }
                imageSlider.smoothScrollToPosition(currentPosition);
                handler.postDelayed(this, 5000); // Adjust the delay as needed
            }
        };


        handler.postDelayed(autoScrollRunnable, 5000); // Initial delay

        Button floatingActionButton = findViewById(R.id.floatingbtn);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ShowArts.this, CaptureImageActivity.class));
            }
        });


        sketches = new ArrayList<>();


        artworkRecyclerView = findViewById(R.id.rv);
        product_category_recycler_view = findViewById(R.id.product_category_recycler_view);
        EditText searchView = findViewById(R.id.searchView);


        product_category_recycler_view.setLayoutManager(new GridLayoutManager(this, 5));
        productCategoryArrayList = new ArrayList<>();
        productCategoryArrayList.add(new ProductCategory("Paintings", R.drawable.painting_art));
        productCategoryArrayList.add(new ProductCategory("Conceptual Art", R.drawable.conceptual_art));
        productCategoryArrayList.add(new ProductCategory("Western Painting", R.drawable.western_painting));
        productCategoryArrayList.add(new ProductCategory("Impressionism Art", R.drawable.impressionism_art));
        productCategoryArrayList.add(new ProductCategory("Latin America Art", R.drawable.latin_america_art));
        productCategoryArrayList.add(new ProductCategory("Landscape Art", R.drawable.landscape_art));
        productCategoryArrayList.add(new ProductCategory("Digital Art", R.drawable.digital_art));
        productCategoryArrayList.add(new ProductCategory("Pakistani Traditional Art", R.drawable.pakistani_traditional_art));
        productCategoryArrayList.add(new ProductCategory("Animation", R.drawable.animation_art));
        productCategoryArrayList.add(new ProductCategory("Others", R.drawable.others_art));
        productCategoryAdapter = new ProductCategoryAdapter(productCategoryArrayList, this, this::onItemClick);
        product_category_recycler_view.setAdapter(productCategoryAdapter);
        artworkAdapter = new ArtworkAdapter(sketches, getApplicationContext());
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        artworkRecyclerView.setLayoutManager(gridLayoutManager);
        artworkRecyclerView.setAdapter(artworkAdapter);


        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Log.d("ShowArts", "Search text: " + charSequence.toString());
                artworkAdapter.filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Do nothing
            }
        });
        fetchArtworks();

    }


    private void fetchArtworks() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("artworks");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                sketches.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Artwork artwork = dataSnapshot.getValue(Artwork.class);
                    if (artwork != null) {
                        sketches.add(artwork);
                    }
                }
                Log.d("ShowArts", "Fetched " + sketches.size() + " artworks from Firebase.");
                artworkAdapter = new ArtworkAdapter(sketches, ShowArts.this);
                artworkRecyclerView.setAdapter(artworkAdapter);

                artworkAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    public void onItemClick(String category) {
        Log.d("ShowArts", "Category clicked: " + category);
        artworkAdapter.filter(category);
    }
}
