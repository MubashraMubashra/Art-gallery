package com.project.virtualartgallery;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.auth.FirebaseAuth;

public class AdminDashboard extends AppCompatActivity {

    private CardView profilebtn;
    private CardView showArts;
    private CardView captureArts;

    private CardView artworkbtn;
    private CardView deleatebtn;
    private CardView logout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        profilebtn = findViewById(R.id.profileManagement);
        showArts = findViewById(R.id.create_exhibition);
        captureArts = findViewById(R.id.cre_exhibition);
        artworkbtn = findViewById(R.id.artwork_list);
        deleatebtn=findViewById(R.id.deleateart);
        logout = findViewById(R.id.logoutad);

        captureArts.setOnClickListener(v -> startActivity(new Intent(this, CaptureImageActivity.class)));
        showArts.setOnClickListener(v -> {
            startActivity(new Intent(this, ShowArts.class));
        });
        profilebtn.setOnClickListener(v -> startActivity(new Intent(this, DisplayUser.class)));

        artworkbtn.setOnClickListener(view -> {
            startActivity(new Intent(this, ShowArts.class));
        });
        deleatebtn.setOnClickListener(v -> startActivity(new Intent(this, DeleateImageActivity.class)));


        logout.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(AdminDashboard.this);
            builder.setTitle("Log Out")
                    .setMessage("Are you sure you want to log out?")
                    .setPositiveButton("LogOut", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            signOutUser();
                        }

                        private void signOutUser() {
                            FirebaseAuth.getInstance().signOut();
                            Toast.makeText(AdminDashboard.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(AdminDashboard.this, HomeScreen.class));
                        }
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();

        });
    }

}
